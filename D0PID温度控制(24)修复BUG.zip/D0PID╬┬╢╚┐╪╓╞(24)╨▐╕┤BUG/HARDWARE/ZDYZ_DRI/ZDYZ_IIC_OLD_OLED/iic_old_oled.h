
//////////////////////////////////////////////////////////////////////////////////	 
//������ֻ��ѧϰʹ�ã�δ���������ɣ��������������κ���;
//
//  �� �� ��   : main.c
//  �� �� ��   : v2.0
//  ��    ��   : 
//  ��������   : 2014-0101
//  ����޸�   : 
//  ��������   : 0.69��OLED �ӿ���ʾ����(STM32F103ZEϵ��IIC)
//              ˵��: 
//              ----------------------------------------------------------------
//              GND   ��Դ��
//              VCC   ��5V��3.3v��Դ
//              SCL   ��PD6��SCL��
//              SDA   ��PD7��SDA��            
//              ----------------------------------------------------------------
//All rights reserved
//////////////////////////////////////////////////////////////////////////////////
#ifndef __IIC_OLD_OLED_H
#define __IIC_OLD_OLED_H		  	 
#include "sys.h"
#include "stdlib.h"	    

#if 0  /*  ����ԭ��ԭ������  */
#define OLED_MODE 0
#define SIZE 8
#define XLevelL		0x00
#define XLevelH		0x10
#define Max_Column	128
#define Max_Row		64
#define	Brightness	0xFF 
#define X_WIDTH 	128
#define Y_WIDTH 	64	    						  
//-----------------OLED IIC�˿ڶ���----------------  					   

#define OLED_SCLK_Clr() GPIO_ResetBits(GPIOD,GPIO_Pin_6)//SDA IIC�ӿڵ�ʱ���ź�
#define OLED_SCLK_Set() GPIO_SetBits(GPIOD,GPIO_Pin_6)

#define OLED_SDIN_Clr() GPIO_ResetBits(GPIOD,GPIO_Pin_7)//SCL IIC�ӿڵ������ź�
#define OLED_SDIN_Set() GPIO_SetBits(GPIOD,GPIO_Pin_7)

 		     
#define OLED_CMD  0	//д����
#define OLED_DATA 1	//д����


//OLED�����ú���
void OLED_WR_Byte(unsigned dat,unsigned cmd);  
void OLED_Display_On(void);
void OLED_Display_Off(void);	   							   		    
void OLED_Init(void);
void OLED_Clear(void);
void OLED_DrawPoint(u8 x,u8 y,u8 t);
void OLED_Fill(u8 x1,u8 y1,u8 x2,u8 y2,u8 dot);
void OLED_ShowChar(u8 x,u8 y,u8 chr,u8 Char_Size);
void OLED_ShowNum(u8 x,u8 y,u32 num,u8 len,u8 size);
void OLED_ShowString(u8 x,u8 y, u8 *p,u8 Char_Size);	 
void OLED_Set_Pos(unsigned char x, unsigned char y);
void OLED_ShowCHinese(u8 x,u8 y,u8 no);
void OLED_DrawBMP(unsigned char x0, unsigned char y0,unsigned char x1, unsigned char y1,unsigned char BMP[]);
void Delay_50ms(unsigned int Del_50ms);
void Delay_1ms(unsigned int Del_1ms);
void fill_picture(unsigned char fill_Data);
void Picture();


void IIC_Start();
void IIC_Stop();
void Write_IIC_Command(unsigned char IIC_Command);
void Write_IIC_Data(unsigned char IIC_Data);
void Write_IIC_Byte(unsigned char IIC_Byte);
void IIC_Wait_Ack();
#endif 

#if 1 /*  �Լ��ʵ��޸�������Ŀ����  */

/* �������Ƿ�֧��OS: 1֧�� 0��֧��  */
#define IIC_OLD_OLED_OS         1

/* �Ĵ������� */
#define IIC_OLD_OLED_MODE           0
#define IIC_OLD_OLED_SIZE           8
#define IIC_OLD_OLED_IXLevelL		0x00
#define IIC_OLD_OLED_XLevelH		0x10
#define IIC_OLD_OLED_Max_Column	    128
#define IIC_OLD_OLED_Max_Row		64
#define	IIC_OLD_OLED_Brightness	    0xFF 
#define IIC_OLD_OLED_X_WIDTH 	    128
#define IIC_OLD_OLED_Y_WIDTH 	    64	    						  

#define IIC_OLD_OLED_CMD  0	//д����
#define IIC_OLD_OLED_DATA 1	//д����

//-----------------OLED IIC�˿�ʱ�Ӷ���----------------  	
#define IIC_OLD_OLED_CLK_CMD    RCC_APB2Periph_GPIOC
//-----------------OLED IIC GPIO�˿ڶ���----------------  	
#define IIC_OLD_OLED_GPIO_POKE  GPIOC
//-----------------OLED IIC�˿���Ŷ���----------------  	
#define IIC_OLD_OLED_SCLK_Pin   GPIO_Pin_4
#define IIC_OLD_OLED_SDIN_Pin   GPIO_Pin_5
//-----------------OLED IIC�˿ڶ���----------------  					   
#define IIC_OLD_OLED_SCLK_Clr() GPIO_ResetBits(IIC_OLD_OLED_GPIO_POKE,IIC_OLD_OLED_SCLK_Pin)//SCL IIC�ӿڵ�ʱ���ź�
#define IIC_OLD_OLED_SCLK_Set() GPIO_SetBits(IIC_OLD_OLED_GPIO_POKE,IIC_OLD_OLED_SCLK_Pin)

#define IIC_OLD_OLED_SDIN_Clr() GPIO_ResetBits(IIC_OLD_OLED_GPIO_POKE,IIC_OLD_OLED_SDIN_Pin)//SDA IIC�ӿڵ������ź�
#define IIC_OLD_OLED_SDIN_Set() GPIO_SetBits(IIC_OLD_OLED_GPIO_POKE,IIC_OLD_OLED_SDIN_Pin)


//OLED�����ú���
void IIC_OLD_OLED_WR_Byte(unsigned dat,unsigned cmd);    
void IIC_OLD_OLED_Display_On(void);
void IIC_OLD_OLED_Display_Off(void);	   							   		    
void IIC_OLD_OLED_Init(void);
void IIC_OLD_OLED_Clear(void);
void IIC_OLD_OLED_Clear_Cow(uint8_t Cow);
void IIC_OLD_OLED_On(void); 
void IIC_OLD_OLED_ShowChar(u8 x,u8 y,u8 chr,u8 Char_Size);
u32 IIC_OLD_oled_pow(u8 m,u8 n);
void IIC_OLD_OLED_ShowNum(u8 x,u8 y,u32 num,u8 len,u8 size2);
void IIC_OLD_OLED_ShowString(u8 x,u8 y,u8 *chr,u8 Char_Size);
void IIC_OLD_OLED_Set_Pos(unsigned char x, unsigned char y);    
void IIC_OLD_OLED_ShowCHinese(u8 x,u8 y,u8 no);
void IIC_OLD_OLED_ShowChStr(u8 x,u8 y,u8 no,u8 num);    
void IIC_OLD_OLED_DrawBMP(unsigned char x0, unsigned char y0,unsigned char x1, unsigned char y1,unsigned char BMP[]);    
void IIC_OLD_OLED_Delay_50ms(unsigned int Del_50ms);
void IIC_OLD_OLED_Delay_1ms(unsigned int Del_1ms);  
void IIC_OLD_OLED_fill_picture(unsigned char fill_Data);    

void IIC_OLD_OLED_IIC_Start(void);
void IIC_OLD_OLED_IIC_Stop(void);
void IIC_OLD_OLED_Write_IIC_Command(unsigned char IIC_Command);
void IIC_OLD_OLED_Write_IIC_Data(unsigned char IIC_Data);
void IIC_OLD_OLED_Write_IIC_Byte(unsigned char IIC_Byte);   
void IIC_OLD_OLED_IIC_Wait_Ack(void);

//////����ĺ���û��ʹ�õ�����г�ͻ����ע�͵�
//void Picture(void);
//void OLED_DrawPoint(u8 x,u8 y,u8 t);
//void OLED_Fill(u8 x1,u8 y1,u8 x2,u8 y2,u8 dot);

#endif 



#endif   ///__IIC_OLD_OLED_H
	 



